package cn.donica.slcd.ble.entity;

/**
 * Project Name:   Donica
 * Create By:      aLinGe
 * Create Time:    2017-09-11 14:31
 * Describe:
 */

public class Config {
    private String name;
    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
