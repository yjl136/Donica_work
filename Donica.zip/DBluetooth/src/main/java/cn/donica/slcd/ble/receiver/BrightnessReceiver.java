package cn.donica.slcd.ble.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Project Name:   Donica
 * Create By:      aLinGe
 * Create Time:    2016-12-05 10:20
 * Describe:
 */
public class BrightnessReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
