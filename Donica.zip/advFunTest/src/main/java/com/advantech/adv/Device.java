package com.advantech.adv;

public class Device {
    public boolean sataFun;
    public boolean udiskFun;
    public boolean keyFun;
    public boolean uartFun;
    public boolean ethFun;
    public boolean audioFun;
    public String sataMsg;
    public String udiskMsg;
    public String keyMsg;
    public String uartMsg;
    public String ethMsg;
    public String audioMsg;
}
